cd ..
cd teamspeak3-server_win32
.\ts3server.exe